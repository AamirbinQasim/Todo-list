function add(){
    var getInput = document.getElementById('todo-items')
    var list = document.createElement('li')
    var displayList = document.createTextNode(getInput.value)
    list.appendChild(displayList)
    var getList = document.getElementById('list')
    getList.appendChild(list)
    var dltbtn = document.createElement('button')
    var dltBtnText = document.createTextNode('Delete')
    dltbtn.appendChild(dltBtnText)
    list.appendChild(dltbtn)
    dltbtn.setAttribute('onclick','delete1(this)') 
    var editBtn = document.createElement('button')
    var editBtnText = document.createTextNode('Edit')
    editBtn.appendChild(editBtnText)
    list.appendChild(editBtn)
    editBtn.setAttribute('onclick','edit(this)')
    getInput.value = ""
}

function edit(e){
    var pr = prompt('enter the updated value',e.parentNode.firstChild.nodeValue)
    e.parentNode.firstChild.nodeValue= pr
}

function deleted(){
    var list = document.getElementById('list')
    list.innerHTML = ""
}

function delete1(e){
    e.parentNode.remove()
}